#pragma once
#include <iostream> 

using namespace std;
int Menu(void);
const int MAX_PPL = 10;


struct HUMAN
{
	char name[18];
	float dist;
	int hat;
};

extern void TulostaHenkilo(HUMAN tyyppi);
extern void TulostaKaikkiHenkilot(HUMAN[], int MAX_PPL);
extern void LisaaHenkilo(HUMAN[], int *a);
