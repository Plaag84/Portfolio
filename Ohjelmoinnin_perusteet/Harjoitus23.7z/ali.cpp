#include "esittely.h"



int Menu(void) // a)
{
	int valikko;
	cout << "VALIKKO" << endl;
	cout << "0 Lopeta" << endl;
	cout << "1 Lisaa henkilo" << endl;
	cout << "2 Nayta kaikki henkilot" << endl;
	cout << "3 Tulosta nykyinen henkilo" << endl;
	cin >> valikko;
	cin.get(); // Poistaa entterin
	return valikko;
}


void TulostaHenkilo(HUMAN tyyppi) // b) 
{
	cout << endl << "Nimi: " << tyyppi.name << endl << "Koulumatkan pituus: " << tyyppi.dist << endl << "Hatun koko: " << tyyppi.hat << endl << endl;

}

void TulostaKaikkiHenkilot(HUMAN a_tyyppi[], int MAX_PPL) // c)
{
	cout << endl << endl << "Nimi, Koulumatka, Hatunkoko" << endl;
	for (int dudes = 0; dudes < MAX_PPL; dudes++)
	{
		cout << a_tyyppi[dudes].name << ", " << a_tyyppi[dudes].dist << ", " << a_tyyppi[dudes].hat << endl;
	}
	cout << endl;
}

void LisaaHenkilo(HUMAN b_tyyppi[], int *a) // d)
{
	cout << endl << "Anna " << *a + 1 << ". Henkil�n etunimi: " << endl;
	cin.get(b_tyyppi[*a].name, 18);
	cout << "Anna " << *a + 1 << ". Henkil�n koulumatkan pituus: " << endl;
	cin >> ws >> b_tyyppi[*a].dist;
	cout << "Anna " << *a + 1 << ". Henkil�n hatun koko: " << endl;
	cin >> ws >> b_tyyppi[*a].hat;
	(*a)++;
	if (*a == MAX_PPL)
	{
		*a = 0;
	}
	else
	{

	}

}